# Menambahkan workflow build APK MateDesk

File yang harus ditambahkan ke **root repository** GitHub:

`.github/workflows/android-apk.yml`

Penting: folder `.github` harus sejajar dengan folder `MateDesk_Laptop_Kit 2`, bukan ditempatkan di dalam folder proyek tersebut.

## Cara melalui website GitHub

1. Buka https://github.com/lintingan/MateDesk
2. Klik **Add file → Create new file**.
3. Pada nama file, masukkan `.github/workflows/android-apk.yml`.
4. Salin isi file `android-apk.yml` dari paket ini ke editor GitHub.
5. Klik **Commit changes** ke branch `main`.
6. Buka tab **Actions** dan pilih **Build MateDesk APK**.
7. Jika belum otomatis berjalan, klik **Run workflow**.
8. Setelah workflow hijau, buka hasil run dan unduh artifact **MateDesk-debug-APK**.

Workflow ini sengaja membangun proyek v0.3.0 pada path `MateDesk_Laptop_Kit 2/android-project`.

## Hasil build

APK debug dihasilkan di:

`MateDesk_Laptop_Kit 2/android-project/app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions mengunggahnya sebagai artifact `MateDesk-debug-APK` selama 14 hari.
